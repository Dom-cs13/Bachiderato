﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ala
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txt1.Text);
            double Num2 = double.Parse(txt2.Text);
            double res = Num1 + Num2;
            txtResultado.Text =  res.ToString();
        }

        private void butDiv_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txt1.Text);
            double Num2 = double.Parse(txt2.Text);
            double res = Num1 / Num2;

            if (Num2 == 0)
            {
                MessageBox.Show("SINTAXIS ERROR");
                return;
            }
            else
            {
                txtResultado.Text = res.ToString();
            }
            
        }

        private void butRes_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txt1.Text);
            double Num2 = double.Parse(txt2.Text);
            double res = Num1 - Num2;
            txtResultado.Text = res.ToString();
        }

        private void butMul_Click(object sender, EventArgs e)
        {
            double Num1 = double.Parse(txt1.Text);
            double Num2 = double.Parse(txt2.Text);
            double res = Num1 * Num2;
            txtResultado.Text = res.ToString();
        }
    }
}
