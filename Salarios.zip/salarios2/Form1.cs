﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InputKey;

namespace salarios2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int sal;
        string[] nombre;
        string[] sala;

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            sal = (int)double.Parse(txtSalario.Text);
            nombre = new string[sal];
            sala = new string[sal];
           
            for (int i = 0; i < sal; i++)
            { 
                nombre[i] = InputDialog.mostrar("Engrase Nombre: ");
                sala[i] = InputDialog.mostrar("ingrese el salario");
                double sal2 = Convert.ToDouble(sala[i]);
                if (sal2 > 3000)
                {
                    double sala3 = (sal2) += sal2 * 0.1;
                    MessageBox.Show("Nombre :  " + nombre[i]);
                    MessageBox.Show("su salario es de : " + sal2);
                }
                else 
                {
                    MessageBox.Show("Nombre :  " + nombre[i]) ;
                    MessageBox.Show("su salario es de : " + sal2);
                }
                   

                
            }




        }
    }
}
