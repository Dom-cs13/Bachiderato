﻿namespace login_de_estudiantes
{
    partial class Calculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNota1 = new System.Windows.Forms.TextBox();
            this.txtNotas2 = new System.Windows.Forms.TextBox();
            this.txtNotas3 = new System.Windows.Forms.TextBox();
            this.txtNotas4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbPromedio = new System.Windows.Forms.Label();
            this.ingreso = new System.Windows.Forms.Button();
            this.lbaprobado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nota 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nota 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nota 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nota 4";
            // 
            // txtNota1
            // 
            this.txtNota1.Location = new System.Drawing.Point(65, 6);
            this.txtNota1.Name = "txtNota1";
            this.txtNota1.Size = new System.Drawing.Size(100, 22);
            this.txtNota1.TabIndex = 4;
            // 
            // txtNotas2
            // 
            this.txtNotas2.Location = new System.Drawing.Point(64, 35);
            this.txtNotas2.Name = "txtNotas2";
            this.txtNotas2.Size = new System.Drawing.Size(100, 22);
            this.txtNotas2.TabIndex = 5;
            // 
            // txtNotas3
            // 
            this.txtNotas3.Location = new System.Drawing.Point(64, 66);
            this.txtNotas3.Name = "txtNotas3";
            this.txtNotas3.Size = new System.Drawing.Size(100, 22);
            this.txtNotas3.TabIndex = 6;
            // 
            // txtNotas4
            // 
            this.txtNotas4.Location = new System.Drawing.Point(64, 101);
            this.txtNotas4.Name = "txtNotas4";
            this.txtNotas4.Size = new System.Drawing.Size(100, 22);
            this.txtNotas4.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Promedio";
            // 
            // lbPromedio
            // 
            this.lbPromedio.AutoSize = true;
            this.lbPromedio.Location = new System.Drawing.Point(176, 137);
            this.lbPromedio.Name = "lbPromedio";
            this.lbPromedio.Size = new System.Drawing.Size(0, 16);
            this.lbPromedio.TabIndex = 9;
            // 
            // ingreso
            // 
            this.ingreso.Location = new System.Drawing.Point(12, 129);
            this.ingreso.Name = "ingreso";
            this.ingreso.Size = new System.Drawing.Size(86, 24);
            this.ingreso.TabIndex = 10;
            this.ingreso.Text = "Ingreso";
            this.ingreso.UseVisualStyleBackColor = true;
            this.ingreso.Click += new System.EventHandler(this.ingreso_Click);
            // 
            // lbaprobado
            // 
            this.lbaprobado.AutoSize = true;
            this.lbaprobado.Location = new System.Drawing.Point(50, 156);
            this.lbaprobado.Name = "lbaprobado";
            this.lbaprobado.Size = new System.Drawing.Size(103, 16);
            this.lbaprobado.TabIndex = 11;
            this.lbaprobado.Text = "Procesando (-.-)";
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(189, 185);
            this.Controls.Add(this.lbaprobado);
            this.Controls.Add(this.ingreso);
            this.Controls.Add(this.lbPromedio);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNotas4);
            this.Controls.Add(this.txtNotas3);
            this.Controls.Add(this.txtNotas2);
            this.Controls.Add(this.txtNota1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Calculadora";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNota1;
        private System.Windows.Forms.TextBox txtNotas2;
        private System.Windows.Forms.TextBox txtNotas3;
        private System.Windows.Forms.TextBox txtNotas4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbPromedio;
        private System.Windows.Forms.Button ingreso;
        private System.Windows.Forms.Label lbaprobado;
    }
}