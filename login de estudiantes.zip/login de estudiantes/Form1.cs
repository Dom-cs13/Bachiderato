﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_de_estudiantes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try-catch

            try
            {
                //byte texto = Convert.ToByte(txtIngreso.Text);
                //lblMostrar.Text = texto.ToString();


                if (txtIngreso.Text == "hola" && txtIngreso2.Text == "1234")
                {
                    this.Hide();
                    Calculadora frm = new Calculadora();
                    frm.Show();

                }
                else
                {
                    MessageBox.Show("Ususario incorrecto");

                }


            }

            catch (OverflowException x)
            {

                MessageBox.Show("el error es: eligió mas de 255 " + x);

            }
            catch (System.FormatException v)
            {

                MessageBox.Show("el error es: eligió otro formato " + v);

            }

        }

        private void txtIngreso2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMostrar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
        
    

