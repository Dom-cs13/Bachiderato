﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_de_estudiantes
{
    public partial class Calculadora : Form
    {
        public Calculadora()
        {
            InitializeComponent();
        }

        private void ingreso_Click(object sender, EventArgs e)
        {

            int nota1 = int.Parse(txtNota1.Text);
            int nota2 = int.Parse(txtNotas2.Text);
            int nota3 =int.Parse(txtNotas3.Text);
            int nota4 = int.Parse(txtNotas4.Text);
            int Prom = (nota1 + nota2 + nota3 + nota4) / 4;
            if (nota4 > 100)
            {
                MessageBox.Show("Error en la nota 4");
            }
            if (nota2 > 100)
            {
                MessageBox.Show("Error en la nota2");
                if (nota3 > 100) { 
                    MessageBox.Show("Error en la nota 3 "); 
                }
                
             if (nota1 > 100)
            {
                MessageBox.Show("error en la nota");
                 
                       
                        
             }
                
                    
            }
            else
            {
                lbPromedio.Text = Prom.ToString();

                if (Prom >= 60)
                {
                    lbaprobado.Text = ("Aprovado");
                }
                else
                {
                    lbaprobado.Text = ("Perdio");
                }
            }
        }
    }
}
